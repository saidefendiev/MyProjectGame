# helico


Educational project, executed according to the training manual.

Console game "Helicopter"
There is a system of saving, moving and upgrading
